﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace db1
{
    public partial class BorrowBookForm : Form
    {
        private MySqlConnection conn;
        public BorrowBookForm(MySqlConnection conn)
        {
            InitializeComponent();
            Borrowprint(conn);
        }

        void Borrowprint(MySqlConnection conn)
        {
            this.conn = conn;

            String sql = "Select * From borrowbook;";
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataSet DS = new DataSet();
            sda.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
            dataGridView1.ReadOnly = true;
        }

        private void new_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                String booknum_str = "";
                if (dataGridView1.Rows[i].Cells[0].Value != null)
                    booknum_str = dataGridView1.Rows[i].Cells[0].Value.ToString();
                if (booknum_txt.Text.Equals(booknum_str))
                {
                    MessageBox.Show("이미 존재하는 청구기호입니다. 다시 확인해주세요.");
                    return;
                }
            }
            String sql = "INSERT INTO borrowbook VALUES('"+booknum_txt.Text + "','" 
                               + bookname_txt.Text + "','" + userid_txt.Text+ "','" + name_txt.Text 
                               + "','" + borrowdate_txt.Text + "','"+ duedate_txt.Text + "')";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            booknum_txt.Clear();
            bookname_txt.Clear();
            userid_txt.Clear();
            name_txt.Clear();
            borrowdate_txt.Clear();
            duedate_txt.Clear();
            conn.Close();
            Borrowprint(conn);
        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String booknum_str = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            String sql = "DELETE FROM borrowbook WHERE booknum = '" + booknum_str + "'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            conn.Close();
            Borrowprint(conn);
        }

        private void update_bt_Click(object sender, EventArgs e)
        {
            booknum_txt.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            bookname_txt.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            userid_txt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            name_txt.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            borrowdate_txt.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            duedate_txt.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            booknum_txt.Enabled = false;
            new_bt.Enabled = false;
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String sql = "UPDATE book SET bookname ='" + bookname_txt.Text 
                + "', userID = '" + userid_txt.Text + "', name = '"+ name_txt.Text + "',borrowDate = '" 
                + borrowdate_txt.Text +"' dueDate = '"+duedate_txt.Text+ "' WHERE booknum='" + booknum_txt.Text + "'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            booknum_txt.Clear();
            bookname_txt.Clear();
            userid_txt.Clear();
            name_txt.Clear();
            borrowdate_txt.Clear();
            duedate_txt.Clear();
            conn.Close();
            Borrowprint(conn);
        }
    }
}
