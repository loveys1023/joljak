﻿namespace db1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.도서검색ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.대출정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도서관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.청구기호인식ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.잘못된위치ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.분실도서ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도서관리ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.회원목록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Login_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.회원가입ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.search_txt = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.borrow_bt = new System.Windows.Forms.Button();
            this.search_bt = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.loginInfo = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.return_bt = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.도서검색ToolStripMenuItem,
            this.대출정보ToolStripMenuItem,
            this.도서관리ToolStripMenuItem,
            this.회원목록ToolStripMenuItem,
            this.Login_ToolStripMenuItem,
            this.회원가입ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(875, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 도서검색ToolStripMenuItem
            // 
            this.도서검색ToolStripMenuItem.Name = "도서검색ToolStripMenuItem";
            this.도서검색ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.도서검색ToolStripMenuItem.Text = "도서검색";
            this.도서검색ToolStripMenuItem.Click += new System.EventHandler(this.도서검색ToolStripMenuItem_Click);
            // 
            // 대출정보ToolStripMenuItem
            // 
            this.대출정보ToolStripMenuItem.Name = "대출정보ToolStripMenuItem";
            this.대출정보ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.대출정보ToolStripMenuItem.Text = "대출정보";
            this.대출정보ToolStripMenuItem.Click += new System.EventHandler(this.대출정보ToolStripMenuItem_Click);
            // 
            // 도서관리ToolStripMenuItem
            // 
            this.도서관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.청구기호인식ToolStripMenuItem,
            this.도서관리ToolStripMenuItem1});
            this.도서관리ToolStripMenuItem.Name = "도서관리ToolStripMenuItem";
            this.도서관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.도서관리ToolStripMenuItem.Text = "도서관리";
            // 
            // 청구기호인식ToolStripMenuItem
            // 
            this.청구기호인식ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.잘못된위치ToolStripMenuItem,
            this.분실도서ToolStripMenuItem});
            this.청구기호인식ToolStripMenuItem.Name = "청구기호인식ToolStripMenuItem";
            this.청구기호인식ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.청구기호인식ToolStripMenuItem.Text = "청구기호인식";
            // 
            // 잘못된위치ToolStripMenuItem
            // 
            this.잘못된위치ToolStripMenuItem.Name = "잘못된위치ToolStripMenuItem";
            this.잘못된위치ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.잘못된위치ToolStripMenuItem.Text = "잘못된 위치";
            this.잘못된위치ToolStripMenuItem.Click += new System.EventHandler(this.잘못된위치ToolStripMenuItem_Click);
            // 
            // 분실도서ToolStripMenuItem
            // 
            this.분실도서ToolStripMenuItem.Name = "분실도서ToolStripMenuItem";
            this.분실도서ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.분실도서ToolStripMenuItem.Text = "분실도서";
            this.분실도서ToolStripMenuItem.Click += new System.EventHandler(this.분실도서ToolStripMenuItem_Click);
            // 
            // 도서관리ToolStripMenuItem1
            // 
            this.도서관리ToolStripMenuItem1.Name = "도서관리ToolStripMenuItem1";
            this.도서관리ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.도서관리ToolStripMenuItem1.Text = "도서관리";
            this.도서관리ToolStripMenuItem1.Click += new System.EventHandler(this.도서관리ToolStripMenuItem1_Click);
            // 
            // 회원목록ToolStripMenuItem
            // 
            this.회원목록ToolStripMenuItem.Name = "회원목록ToolStripMenuItem";
            this.회원목록ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.회원목록ToolStripMenuItem.Text = "회원관리";
            this.회원목록ToolStripMenuItem.Click += new System.EventHandler(this.회원목록ToolStripMenuItem_Click);
            // 
            // Login_ToolStripMenuItem
            // 
            this.Login_ToolStripMenuItem.Name = "Login_ToolStripMenuItem";
            this.Login_ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.Login_ToolStripMenuItem.Text = "로그인";
            this.Login_ToolStripMenuItem.Click += new System.EventHandler(this.Login_ToolStripMenuItem_Click);
            // 
            // 회원가입ToolStripMenuItem
            // 
            this.회원가입ToolStripMenuItem.Name = "회원가입ToolStripMenuItem";
            this.회원가입ToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.회원가입ToolStripMenuItem.Text = "회원가입";
            this.회원가입ToolStripMenuItem.Click += new System.EventHandler(this.회원가입ToolStripMenuItem_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "전체",
            "도서명",
            "저자",
            "출판사",
            "청구기호"});
            this.comboBox1.Location = new System.Drawing.Point(20, 39);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 1;
            // 
            // search_txt
            // 
            this.search_txt.Location = new System.Drawing.Point(147, 39);
            this.search_txt.Name = "search_txt";
            this.search_txt.Size = new System.Drawing.Size(418, 21);
            this.search_txt.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.borrow_bt);
            this.panel1.Controls.Add(this.search_bt);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.search_txt);
            this.panel1.Location = new System.Drawing.Point(70, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(761, 97);
            this.panel1.TabIndex = 3;
            // 
            // borrow_bt
            // 
            this.borrow_bt.Location = new System.Drawing.Point(684, 32);
            this.borrow_bt.Name = "borrow_bt";
            this.borrow_bt.Size = new System.Drawing.Size(72, 32);
            this.borrow_bt.TabIndex = 4;
            this.borrow_bt.Text = "대출";
            this.borrow_bt.UseVisualStyleBackColor = true;
            this.borrow_bt.Click += new System.EventHandler(this.borrow_bt_Click);
            // 
            // search_bt
            // 
            this.search_bt.Location = new System.Drawing.Point(591, 32);
            this.search_bt.Name = "search_bt";
            this.search_bt.Size = new System.Drawing.Size(72, 32);
            this.search_bt.TabIndex = 3;
            this.search_bt.Text = "검색";
            this.search_bt.UseVisualStyleBackColor = true;
            this.search_bt.Click += new System.EventHandler(this.search_bt_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(40, 137);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(823, 396);
            this.dataGridView1.TabIndex = 4;
            // 
            // loginInfo
            // 
            this.loginInfo.AutoSize = true;
            this.loginInfo.Location = new System.Drawing.Point(612, 9);
            this.loginInfo.Name = "loginInfo";
            this.loginInfo.Size = new System.Drawing.Size(0, 12);
            this.loginInfo.TabIndex = 5;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(39, 120);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 23;
            this.dataGridView2.Size = new System.Drawing.Size(824, 451);
            this.dataGridView2.TabIndex = 6;
            // 
            // return_bt
            // 
            this.return_bt.Location = new System.Drawing.Point(774, 539);
            this.return_bt.Name = "return_bt";
            this.return_bt.Size = new System.Drawing.Size(72, 32);
            this.return_bt.TabIndex = 5;
            this.return_bt.Text = "반납";
            this.return_bt.UseVisualStyleBackColor = true;
            this.return_bt.Click += new System.EventHandler(this.return_bt_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 583);
            this.Controls.Add(this.return_bt);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.loginInfo);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "도서관리프로그램";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 도서검색ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대출정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도서관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 회원목록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Login_ToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox search_txt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button search_bt;
        private System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.Label loginInfo;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button borrow_bt;
        private System.Windows.Forms.Button return_bt;
        private System.Windows.Forms.ToolStripMenuItem 회원가입ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 청구기호인식ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 잘못된위치ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 분실도서ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도서관리ToolStripMenuItem1;
    }
}

