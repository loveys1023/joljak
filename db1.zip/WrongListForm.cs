﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace db1
{
    public partial class WrongListForm : Form
    {
        private MySqlConnection conn;
        string CALL_NUMBER_PATH_PTR = "C:/Users/kimyu/Desktop/callnum/";
        string[] date_folder;
        MySqlDataAdapter sda;
        DataSet DS = new DataSet();

        private void SetupDataGridView()
        {
            DataColumn col = new DataColumn();
            col.DataType = System.Type.GetType("System.String");
            col.ColumnName = "now_shelf_num";
            col.DefaultValue = "NULL";
            DS.Tables[0].Columns.Add(col);
        }

        void Bookprint(String sql, int count, string loc)
        {
            sda = new MySqlDataAdapter(sql, conn);
            sda.Fill(DS);
            if(count == 1 ) SetupDataGridView();
            dataGridView1.DataSource = DS.Tables[0];
            DS.Tables[0].Rows[DS.Tables[0].Rows.Count-1][7] = loc;
            dataGridView1.ReadOnly = true;
        }

        String Now_Location(string booknum)
        {
            conn.Open();
            String sql = "SELECT shelf_num FROM book WHERE booknum = '" + booknum + "'";
            MySqlCommand mycommand = new MySqlCommand(sql, conn);

            String shelf_num = (mycommand.ExecuteScalar()).ToString();
            conn.Close();
            return shelf_num;
            
        }

        public WrongListForm(MySqlConnection conn)
        {
            InitializeComponent();
            dataGridView1.Hide();
            this.conn = conn;

            List<string> date_folder_list = new List<string>();
            DirectoryInfo Info = new DirectoryInfo(CALL_NUMBER_PATH_PTR);
            DirectoryInfo[] Cinfo = Info.GetDirectories();
            foreach(DirectoryInfo info in Cinfo)
            {
                comboBox1.Items.Add(info.Name);
                date_folder_list.Add(info.Name);
            }
            date_folder = date_folder_list.ToArray();
        }

        private void sort_array(string[] callNum)
        {
            
            int count = 1;
            for (int i = 0; i < callNum.Length; i++)
            {    
                string eng_code_na = callNum[i].Substring(0, 2);
                int code_num_na = Convert.ToInt32(callNum[i].Substring(2, 4));
                if (i == 0)
                {
                    string eng_code_after = callNum[i + 1].Substring(0, 2);
                    int code_num_after = Convert.ToInt32(callNum[i + 1].Substring(2, 4));
                    if (eng_code_after == eng_code_na)
                    {                        
                        if (code_num_after < code_num_na)
                        {
                            int code_num_aafter = Convert.ToInt32(callNum[i + 2].Substring(2, 4));
                            if (code_num_aafter < code_num_na)
                            {
                                int next = i + 1;
                                string now_location = Now_Location(callNum[next]);
                                String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i] + "'";
                                Bookprint(sql3, count, now_location);
                                count = 0;
                                i++;
                            }
                        }
                    }
                }
                else if (i == callNum.Length - 1)
                {
                    string eng_code_before = callNum[i - 1].Substring(0, 2);
                    int code_num_before = Convert.ToInt32(callNum[i - 1].Substring(2, 4));
                    if (eng_code_na == eng_code_before)
                    {
                        if (code_num_before > code_num_na)
                        {
                            int next = i + 1;
                            string now_location = Now_Location(callNum[next]);
                            String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i] + "'";
                            Bookprint(sql3, count, now_location);
                            count = 0;
                            i++;
                        }
                    }
                    else
                    {
                        dataGridView1.Rows.Add(callNum[i]);
                        i++;
                    }
                }
                else
                {
                    string eng_code_before = callNum[i - 1].Substring(0, 2);
                    int code_num_before = Convert.ToInt32(callNum[i - 1].Substring(2, 4));
                    int next1 = i + 1;
                    string eng_code_after = callNum[next1].Substring(0, 2);
                    int code_num_after = Convert.ToInt32(callNum[i + 1].Substring(2, 4));

                    if (eng_code_na == eng_code_before && eng_code_na == eng_code_after)
                    {
                        if((code_num_na < code_num_before) && (code_num_na < code_num_after))
                        {
                            int next2 = i + 1;
                            string now_location = Now_Location(callNum[next2]);
                            String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i] + "'";
                            Bookprint(sql3, count, now_location);
                            count = 0;
                            i++;
                        }
                        else if((code_num_na > code_num_before) && (code_num_na > code_num_after))
                        {
                            if(code_num_before > code_num_after)
                            {
                                int next = i + 2;
                                string now_location = Now_Location(callNum[next]);
                                String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i+1] + "'";
                                Bookprint(sql3, count, now_location);
                                count = 0;
                                i += 2;
                            }
                            else if (code_num_before < code_num_after)
                            {
                                int next = i + 1;
                                string now_location = Now_Location(callNum[next]);
                                String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i] + "'";
                                Bookprint(sql3, count, now_location);
                                count = 0;
                                i++;
                            }                            
                        }
                    }
                    else if (eng_code_na != eng_code_before && eng_code_na != eng_code_after && eng_code_before == eng_code_after)
                    {
                        int next = i + 1;
                        string now_location = Now_Location(callNum[next]);
                        String sql3 = "SELECT * FROM book WHERE booknum = '" + callNum[i] + "'";
                        Bookprint(sql3, count, now_location);
                        count = 0;
                        i++;
                    }
                }               
            }
        }

        private void search_bt_Click(object sender, EventArgs e)
        {
            string date = comboBox1.SelectedItem as String;
            
            dataGridView1.Show();
            for (int i = 0; i < date_folder.Length; i++)
            {
                if (date == date_folder[i])
                {
                    string TEXT_PATH = CALL_NUMBER_PATH_PTR + date_folder[i] + "/txt/";
                    string[] FILE_LIST = Directory.GetFiles(TEXT_PATH);

                    for (int j = 0; j < FILE_LIST.Length; j++)
                    {
                        string CALL_NUMBER_PATH = FILE_LIST[j];
                        string[] callNum = System.IO.File.ReadAllLines(@CALL_NUMBER_PATH);

                        sort_array(callNum);
                    }
                 }
             }
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("해당하는 도서가 없습니다.");
            }
        }
    }    
}
