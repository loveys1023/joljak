﻿namespace db1
{
    partial class userManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userManageForm));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.new_bt = new System.Windows.Forms.Button();
            this.edit_bt = new System.Windows.Forms.Button();
            this.delete_bt = new System.Windows.Forms.Button();
            this.save_bt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.userID_txt = new System.Windows.Forms.TextBox();
            this.position_txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.password_txt = new System.Windows.Forms.TextBox();
            this.major_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 163);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(579, 273);
            this.dataGridView1.TabIndex = 1;
            // 
            // new_bt
            // 
            this.new_bt.Location = new System.Drawing.Point(289, 455);
            this.new_bt.Name = "new_bt";
            this.new_bt.Size = new System.Drawing.Size(71, 24);
            this.new_bt.TabIndex = 0;
            this.new_bt.Text = "등록";
            this.new_bt.UseVisualStyleBackColor = true;
            this.new_bt.Click += new System.EventHandler(this.new_bt_Click);
            // 
            // edit_bt
            // 
            this.edit_bt.Location = new System.Drawing.Point(443, 455);
            this.edit_bt.Name = "edit_bt";
            this.edit_bt.Size = new System.Drawing.Size(71, 24);
            this.edit_bt.TabIndex = 1;
            this.edit_bt.Text = "수정";
            this.edit_bt.UseVisualStyleBackColor = true;
            this.edit_bt.Click += new System.EventHandler(this.edit_bt_Click);
            // 
            // delete_bt
            // 
            this.delete_bt.Location = new System.Drawing.Point(366, 455);
            this.delete_bt.Name = "delete_bt";
            this.delete_bt.Size = new System.Drawing.Size(71, 24);
            this.delete_bt.TabIndex = 2;
            this.delete_bt.Text = "삭제";
            this.delete_bt.UseVisualStyleBackColor = true;
            this.delete_bt.Click += new System.EventHandler(this.delete_bt_Click);
            // 
            // save_bt
            // 
            this.save_bt.Location = new System.Drawing.Point(520, 455);
            this.save_bt.Name = "save_bt";
            this.save_bt.Size = new System.Drawing.Size(71, 24);
            this.save_bt.TabIndex = 3;
            this.save_bt.Text = "저장";
            this.save_bt.UseVisualStyleBackColor = true;
            this.save_bt.Click += new System.EventHandler(this.save_bt_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.userID_txt);
            this.panel1.Controls.Add(this.position_txt);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.phone_txt);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.password_txt);
            this.panel1.Controls.Add(this.major_txt);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.name_txt);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 123);
            this.panel1.TabIndex = 10;
            // 
            // userID_txt
            // 
            this.userID_txt.Location = new System.Drawing.Point(73, 14);
            this.userID_txt.Name = "userID_txt";
            this.userID_txt.Size = new System.Drawing.Size(114, 21);
            this.userID_txt.TabIndex = 13;
            // 
            // position_txt
            // 
            this.position_txt.Location = new System.Drawing.Point(335, 88);
            this.position_txt.Name = "position_txt";
            this.position_txt.Size = new System.Drawing.Size(114, 21);
            this.position_txt.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(298, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "직위";
            // 
            // phone_txt
            // 
            this.phone_txt.Location = new System.Drawing.Point(335, 51);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(114, 21);
            this.phone_txt.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(264, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "핸드폰번호";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 9;
            this.label6.Text = "비밀번호";
            // 
            // password_txt
            // 
            this.password_txt.Location = new System.Drawing.Point(335, 14);
            this.password_txt.Name = "password_txt";
            this.password_txt.Size = new System.Drawing.Size(114, 21);
            this.password_txt.TabIndex = 3;
            // 
            // major_txt
            // 
            this.major_txt.Location = new System.Drawing.Point(73, 84);
            this.major_txt.Name = "major_txt";
            this.major_txt.Size = new System.Drawing.Size(114, 21);
            this.major_txt.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "학과";
            // 
            // name_txt
            // 
            this.name_txt.Location = new System.Drawing.Point(73, 47);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(114, 21);
            this.name_txt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "이름";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "학번";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(37, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 12);
            this.label7.TabIndex = 11;
            // 
            // userManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(603, 491);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.save_bt);
            this.Controls.Add(this.delete_bt);
            this.Controls.Add(this.edit_bt);
            this.Controls.Add(this.new_bt);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "userManageForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "회원 관리";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 도서검색ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대출정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도서등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 회원목록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그인ToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button new_bt;
        private System.Windows.Forms.Button edit_bt;
        private System.Windows.Forms.Button delete_bt;
        private System.Windows.Forms.Button save_bt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox major_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox position_txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox password_txt;
        private System.Windows.Forms.TextBox userID_txt;
        private System.Windows.Forms.Label label7;
    }
}