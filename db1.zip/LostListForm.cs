﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace db1
{
    public partial class LostListForm : Form
    {
        private MySqlConnection conn;
        string CALL_NUMBER_PATH_PTR = "C:/Users/kimyu/Desktop/callnum/";
        string[] date_folder;
        MySqlDataAdapter sda ;
        DataSet DS = new DataSet();



        public LostListForm(MySqlConnection conn)
        {
            InitializeComponent();
            dataGridView1.Hide();
            this.conn = conn;

            List<string> date_folder_list = new List<string>();
            DirectoryInfo Info = new DirectoryInfo(CALL_NUMBER_PATH_PTR);
            DirectoryInfo[] Cinfo = Info.GetDirectories();
            foreach (DirectoryInfo info in Cinfo)
            {
                comboBox1.Items.Add(info.Name);
                date_folder_list.Add(info.Name);
            }
            date_folder = date_folder_list.ToArray();
        }

        private void wrong_or_lost(string[] callNum)
        {
            int count = 0;
            conn.Open();
            List<int> no_list = new List<int>();
            for (int i = 0; i < callNum.Length-1; i++)
            {
                String sql1 = "SELECT no FROM book WHERE booknum = '" + callNum[i] + "'";
                String sql2 = "SELECT no FROM book WHERE booknum = '" + callNum[i + 1] + "'";
                MySqlCommand mycommand1 = new MySqlCommand(sql1, conn);
                MySqlCommand mycommand2 = new MySqlCommand(sql2, conn);
                
                int no_na = Convert.ToInt32(mycommand1.ExecuteScalar());
                int no_after = Convert.ToInt32(mycommand2.ExecuteScalar());
                if (no_after - no_na == 2)
                {
                    no_list.Add(no_na + 1);
                }
                for(int j = 0; j < no_list.Count; j++) { 
                    if (no_list[j] == no_na)
                    {
                        no_list.Remove(no_list[j]);
                    }
                }
            }
            
            for (int i = 0; i < no_list.Count; i++)
            {
                
                String sql = "SELECT availability FROM book WHERE no = '" + no_list[i] + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);

                String availability = mycommand.ExecuteScalar().ToString();

                if(availability == "O")
                {
                    String sql2 = "SELECT * FROM book WHERE no = '" + no_list[i] + "'";
                    Bookprint(sql2);
                }  
            }
            conn.Close();

        }
        
        void Bookprint(String sql)
        {
            //this.conn = conn;
            sda = new MySqlDataAdapter(sql, conn);
            sda.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
            dataGridView1.ReadOnly = true;
        }

        private void search_bt_Click(object sender, EventArgs e)
        {
            dataGridView1.Show();
            for (int i = 0; i < date_folder.Length; i++)
            {
                String date = comboBox1.SelectedItem as String;
                if (date == date_folder[i])
                {
                    string TEXT_PATH = CALL_NUMBER_PATH_PTR + date_folder[i] + "/txt/";
                    string[] FILE_LIST = Directory.GetFiles(TEXT_PATH);

                    for (int j = 0; j < FILE_LIST.Length; j++)
                    {
                        string CALL_NUMBER_PATH = FILE_LIST[j];
                        string[] callNum = System.IO.File.ReadAllLines(@CALL_NUMBER_PATH);

                        wrong_or_lost(callNum);
                    }

                }
            }
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("해당하는 도서가 없습니다.");
            }
        }
    }
}
