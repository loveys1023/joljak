﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace db1
{
    public partial class NewJoin : Form
    {
        private MySqlConnection conn;
        Boolean dup_check = false;
        public NewJoin(MySqlConnection conn)
        {
            InitializeComponent();
            this.conn = conn;
            
        }

        private void duplication_bt_Click(object sender, EventArgs e)
        {
            String sql = "Select Count(*) from userinfo"+ 
                "where userID = '" + userID_txt.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataTable userinfo1 = new DataTable();
            sda.Fill(userinfo1);
            // duplication Check
            if (userinfo1.Rows[0][0].ToString() == "1")
            {
                MessageBox.Show("duplication Check fail");
                dup_check = false;
            }
            else
            {
                MessageBox.Show("duplication Check success");
                dup_check = true;
            }
        }
        private void new_bt_Click(object sender, EventArgs e)
        {
            if(dup_check == false)
            {
                MessageBox.Show("Take duplication Check");
                return;
            }
            if (!password_txt.Text.Equals(password_check.Text))
            {
                MessageBox.Show("Check Password !!!!!");
                return;
            }
            if (position_txt.Text.Equals("학사")|| position_txt.Text.Equals("석사")
                || position_txt.Text.Equals("박사"))
            {
                conn.Open();
                String sql = "INSERT INTO userinfo VALUES('" 
                    + userID_txt.Text + "','" + name_txt.Text + "','" + phone_txt.Text
                    + "','" + major_txt.Text + "','" + position_txt.Text
                    + "','" + password_txt.Text + "')";
                MySqlCommand MyCommand = new MySqlCommand(sql, conn);
                MyCommand.ExecuteNonQuery();
                MessageBox.Show("Success !~!~!~!~!");
                userID_txt.Clear();
                name_txt.Clear();
                phone_txt.Clear();
                major_txt.Clear();
                position_txt.Clear();
                password_txt.Clear();
                password_check.Clear();
                conn.Close();
                this.Close();
            }
            else
            {
                MessageBox.Show("Check Position!!");
            }
        }
    }
}
