﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace db1
{
   
    public partial class LoginForm : Form
    {
       
        private MySqlConnection conn;
        //MainForm frm1 = new MainForm();
        public LoginForm(MySqlConnection conn)
        {
            InitializeComponent();
            this.conn = conn;
        }

        private void login_Click(object sender, EventArgs e)
        {
            String sql = "Select Count(*) from userinfo where userID='" + id_txt.Text + 
                "' and password='" + pw_txt.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataTable userinfo1 = new DataTable();
            sda.Fill(userinfo1);
            
            if (userinfo1.Rows[0][0].ToString() == "1")
            {//로그인 성공
                conn.Open();
                MainForm Mf = (MainForm)this.Owner;
                Mf.Passvalue = id_txt.Text;
                String sql1 = "SELECT name from userinfo where userID='" + id_txt.Text + "'";
                MySqlCommand MyCommand = new MySqlCommand(sql1, conn);
                
                var username = MyCommand.ExecuteScalar();
                MessageBox.Show(username.ToString() +"님 환영합니다.");
                Mf.loginInfo.Text = username.ToString()+"님 환영합니다.";
                Mf.Show();
                conn.Close();
                
                this.Close();
            }
            else
            {
                MessageBox.Show("아이디와 비밀번호를 확인해주세요.");
            }
        }
    }
}
