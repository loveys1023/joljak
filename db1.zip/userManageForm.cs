﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace db1
{
    public partial class userManageForm : Form
    {
        private MySqlConnection conn;

        void Userprint(MySqlConnection conn)
        {
            this.conn = conn;

            String sql = "Select * From userinfo;";
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataSet DS = new DataSet();
            sda.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
            dataGridView1.ReadOnly = true;
            
        }

        public userManageForm(MySqlConnection conn)
        {
            InitializeComponent();
            Userprint(conn);
        }

        private void edit_bt_Click(object sender, EventArgs e)
        {

            userID_txt.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            name_txt.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            phone_txt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            major_txt.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            position_txt.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            password_txt.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            userID_txt.Enabled = false;
            new_bt.Enabled = false;
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String sql = "UPDATE userinfo SET name='" + name_txt.Text + "',phone='" + phone_txt.Text + "',major='" + major_txt.Text 
                      + "',position='" + position_txt.Text + "',password='" + password_txt.Text + "'WHERE userID='" + userID_txt.Text + "'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            userID_txt.Clear();
            name_txt.Clear();
            phone_txt.Clear();
            major_txt.Clear();
            position_txt.Clear();
            password_txt.Clear();
            conn.Close();
            Userprint(conn);
        }

        private void new_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            int userID_int = Convert.ToInt32(userID_txt.Text);
            for (int i = 0; i < dataGridView1.RowCount; i++)
            {
                if (userID_int == Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value))
                {
                    MessageBox.Show("중복된 학번입니다. 다시 확인해주세요.");
                    return;
                }
            }
            String sql = "INSERT INTO userinfo VALUES ('" + userID_txt.Text + "','" + name_txt.Text + "','"
                          + phone_txt.Text + "','" + major_txt.Text+ "','" + position_txt.Text + "','" + password_txt.Text + "')";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
           MyCommand.ExecuteNonQuery();
            userID_txt.Clear();
            name_txt.Clear();
            phone_txt.Clear();
            major_txt.Clear();
            position_txt.Clear();
            password_txt.Clear();
            conn.Close();
            Userprint(conn);
        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String userid_str = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            String sql = "DELETE FROM userinfo WHERE userID='" + userid_str + "'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
           MyCommand.ExecuteNonQuery();
            conn.Close();
            Userprint(conn);
        }


    }

}
