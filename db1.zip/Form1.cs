﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Common;
namespace db1
{
    public partial class MainForm : Form
    {
        MySqlConnection conn = new MySqlConnection(@"server = localhost; user = root; password = bigbang12; database = bookdb");
        public string Passvalue = "";

        public MainForm()
        {
            InitializeComponent();
            panel1.Hide();
            dataGridView1.Hide();
            dataGridView2.Hide();
            return_bt.Hide();
            
        }

        private void Login_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoginForm loginForm1 = new LoginForm(conn);
            loginForm1.Owner = this;
            loginForm1.Show();
        } 
        private void 회원가입ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewJoin newjoinForm = new NewJoin(conn);
            newjoinForm.Owner = this;
            newjoinForm.Show();
        }

        private void 회원목록ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Passvalue == "") MessageBox.Show("접근권한이 없습니다.");
            else
            {
                String manager = "관리자";
                String sql = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);
                conn.Open();
                String position = mycommand.ExecuteScalar().ToString();
                if (position.Equals(manager))
                {
                    userManageForm userManageForm = new userManageForm(conn);
                    userManageForm.Show();
                }
                else
                {
                    MessageBox.Show("접근권한이 없습니다.");
                }
                conn.Close();
            }
        }

        private void 도서검색ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView2.Hide();
            return_bt.Hide();
            panel1.Show();
        }



        private void search_bt_Click(object sender, EventArgs e)
        {
            String category = comboBox1.SelectedItem as String;
            String sql;
            if (category == "도서명")
                sql = "SELECT * FROM book WHERE bookname='" + search_txt.Text + "'";
            else if (category == "저자")
                sql = "SELECT * FROM book WHERE writer='" + search_txt.Text + "'";
            else if (category == "출판사")
                sql = "SELECT * FROM book WHERE publisher='" + search_txt.Text + "'";
            else if (category == "청구기호")
                sql = "SELECT * FROM book WHERE booknum='" + search_txt.Text + "'";
            else if (category == "전체")
                sql = "SELECT * FROM book WHERE bookname='" + search_txt.Text +
                    "' OR writer ='" + search_txt.Text + "' OR publisher='" +
                    search_txt.Text + "' OR booknum='" + search_txt.Text + "'";
            else
            {
                MessageBox.Show("카테고리를 선택해주세요.");
                return;
            }
            dataGridView1.Show();
            Bookprint(sql);
        }

        void Bookprint(String sql)
        {
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataSet DS = new DataSet();
            sda.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
            dataGridView1.ReadOnly = true;
            if (dataGridView1.RowCount == 0)
            {
                MessageBox.Show("해당하는 도서가 없습니다.");
            }
        }

        void borrowInfo_print(String sql)
        {
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataSet DS = new DataSet();
            sda.Fill(DS);
            dataGridView2.DataSource = DS.Tables[0];
            dataGridView2.ReadOnly = true;
            if (dataGridView2.RowCount == 0)
            {
                MessageBox.Show("해당하는 도서가 없습니다.");
            }
        }

        private void 대출정보ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            dataGridView1.Hide();
           
            if (Passvalue.Equals(""))
            {
                MessageBox.Show("로그인 후 이용해주세요.");
                return;
            }

            return_bt.Show();
            String sql = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
            MySqlCommand mycommand = new MySqlCommand(sql, conn);
            conn.Open();
            String position = mycommand.ExecuteScalar().ToString();
            if (position.Equals("관리자"))
            {
               BorrowBookForm borrowbookForm = new BorrowBookForm(conn);
               borrowbookForm.Show();
            }
            else
            {
               String sql1 = "SELECT * FROM borrowbook WHERE userID='" + Passvalue + "'";
               MySqlCommand mycommand1 = new MySqlCommand(sql1, conn);
               borrowInfo_print(sql1);
               dataGridView2.Show();
            }
            conn.Close();
        }


        private void borrow_bt_Click(object sender, EventArgs e)
        {
            if (Passvalue.Equals(""))
            {
                MessageBox.Show("로그인 후 이용해주세요");
                return;
            }

            if (dataGridView1.CurrentRow.Cells[5].Value.ToString().Equals("O"))
            {
                String userID = Passvalue;
                String booknum = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                String bookname = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                conn.Open();
                String sql = "SELECT name FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);
                String name = mycommand.ExecuteScalar().ToString();

                String sql1 = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand1 = new MySqlCommand(sql1, conn);
                String position = mycommand1.ExecuteScalar().ToString();
                int borrowDay;
                MessageBox.Show(position);
                if (position.Equals("학사")) borrowDay = 7;
                else if (position.Equals("석사")) borrowDay = 14;
                else borrowDay = 30;

                String sql_book = "UPDATE book SET availability= 'X' WHERE booknum='" + booknum + "'";
                String sql_borrow = "INSERT INTO borrowbook VALUE('" + booknum + "','" 
                    + bookname + "','" + userID + "','" + name + "',NOW(), NOW()+interval "
                    + borrowDay + " DAY)";
                MySqlCommand mycommand_book = new MySqlCommand(sql_book, conn);
                MySqlCommand mycommand_borrow = new MySqlCommand(sql_borrow, conn);
                mycommand_book.ExecuteNonQuery();
                mycommand_borrow.ExecuteNonQuery();
     
                String sql_duedate = "SELECT dueDate FROM borrowbook WHERE booknum = '" + booknum+"'";
                MySqlCommand mycommand_due = new MySqlCommand(sql_duedate, conn);
                String dueDate = mycommand_due.ExecuteScalar().ToString();
                MessageBox.Show("대출되었습니다. 반납일은 "+dueDate+" 입니다.");
                conn.Close();
                search_bt_Click(sender, e);
              
            }
            else
            {
                MessageBox.Show("이미 대출중인 도서입니다.");
            }
        }

        private void return_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String booknum = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            String sql_return = "DELETE FROM borrowbook WHERE booknum='" + booknum + "'";
            String sql_book = "UPDATE book SET availability= 'O' WHERE booknum='" + booknum + "'";

            MySqlCommand mycommand_return = new MySqlCommand(sql_return, conn);
            MySqlCommand mycommand_sql_book = new MySqlCommand(sql_book, conn);
            mycommand_return.ExecuteNonQuery();
            mycommand_sql_book.ExecuteNonQuery();
            MessageBox.Show("반납되었습니다.");
            conn.Close();
            대출정보ToolStripMenuItem_Click(sender, e);
        }

        private void 도서관리ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            dataGridView2.Hide();
            return_bt.Hide();
            panel1.Hide();
            if (Passvalue == "") MessageBox.Show("접근권한이 없습니다.");
            else
            {
                String manager = "관리자";
                String sql = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);
                conn.Open();
                String position = mycommand.ExecuteScalar().ToString();
                if (position.Equals(manager))
                {
                    BookManageForm bookmanageForm = new BookManageForm(conn);
                    bookmanageForm.Show();
                }
                else
                {
                    MessageBox.Show("접근권한이 없습니다.");
                }
                conn.Close();
            }
        }

        private void 잘못된위치ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView2.Hide();
            return_bt.Hide();
            panel1.Hide();
            if (Passvalue == "") MessageBox.Show("접근권한이 없습니다.");
            else
            {
                String manager = "관리자";
                String sql = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);
                conn.Open();
                String position = mycommand.ExecuteScalar().ToString();
                if (position.Equals(manager))
                {
                    WrongListForm wronglistForm = new WrongListForm(conn);
                    wronglistForm.Show();
                }
                else
                {
                    MessageBox.Show("접근권한이 없습니다.");
                }
                conn.Close();
            }
        }

        private void 분실도서ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView2.Hide();
            return_bt.Hide();
            panel1.Hide();
            if (Passvalue == "") MessageBox.Show("접근권한이 없습니다.");
            else
            {
                String manager = "관리자";
                String sql = "SELECT position FROM userinfo WHERE userID='" + Passvalue + "'";
                MySqlCommand mycommand = new MySqlCommand(sql, conn);
                conn.Open();
                String position = mycommand.ExecuteScalar().ToString();
                if (position.Equals(manager))
                {
                    LostListForm lostlistForm = new LostListForm(conn);
                    lostlistForm.Show();
                }
                else
                {
                    MessageBox.Show("접근권한이 없습니다.");
                }
                conn.Close();
            }
        }
    }
}
