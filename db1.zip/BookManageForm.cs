﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace db1
{
    public partial class BookManageForm : Form
    {
        private MySqlConnection conn;

        void Userprint(MySqlConnection conn)
        {
            this.conn = conn;

            String sql = "Select * From book;";
            MySqlDataAdapter sda = new MySqlDataAdapter(sql, conn);
            DataSet DS = new DataSet();
            sda.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];
            dataGridView1.ReadOnly = true;
        }

        public BookManageForm(MySqlConnection conn)
        {
            InitializeComponent();
            Userprint(conn);
        }

        private void edit_bt_Click(object sender, EventArgs e)
        {
            booknum_txt.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            bookname_txt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            writer_txt.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            publisher_txt.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            availability_txt.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            booknum_txt.Enabled = false;
            new_bt.Enabled = false;
        }

        private void save_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String sql = "UPDATE book SET bookname ='"+bookname_txt.Text+"', writer = '"+writer_txt.Text +"', publisher = '"
                        +publisher_txt.Text+"',availability = '"+availability_txt.Text+"' WHERE booknum='"+booknum_txt.Text+"'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            booknum_txt.Clear();
            bookname_txt.Clear();
            writer_txt.Clear(); 
            publisher_txt.Clear();
            availability_txt.Clear();
            conn.Close();
            Userprint(conn);
        }

        private void new_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            for(int i = 0; i < dataGridView1.RowCount; i++)
            {
                String booknum_str = "";
                if(dataGridView1.Rows[i].Cells[0].Value != null)
                {
                    booknum_str = dataGridView1.Rows[i].Cells[0].Value.ToString();
                }
                
                if (booknum_txt.Text.Equals(booknum_str))
                {
                    MessageBox.Show("이미 존재하는 청구기호입니다. 다시 확인해주세요.");
                    return;
                }
            }
            String sql = "INSERT INTO book VALUES('" + booknum_txt.Text + "','" + bookname_txt.Text + "','" + writer_txt.Text 
                         + "','" + publisher_txt.Text + "','" + availability_txt.Text + "')";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            booknum_txt.Clear();
            bookname_txt.Clear();
            writer_txt.Clear();
            publisher_txt.Clear();
            availability_txt.Clear();
            conn.Close();
            Userprint(conn);
        }

        private void delete_bt_Click(object sender, EventArgs e)
        {
            conn.Open();
            String booknum_str = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            String sql = "DELETE FROM book WHERE booknum = '" + booknum_str + "'";
            MySqlCommand MyCommand = new MySqlCommand(sql, conn);
            MyCommand.ExecuteNonQuery();
            conn.Close();
            Userprint(conn);
        }
    }
}
