﻿namespace db1
{
    partial class BorrowBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.booknum_txt = new System.Windows.Forms.TextBox();
            this.bookname_txt = new System.Windows.Forms.TextBox();
            this.duedate_txt = new System.Windows.Forms.TextBox();
            this.userid_txt = new System.Windows.Forms.TextBox();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.borrowdate_txt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.new_bt = new System.Windows.Forms.Button();
            this.save_bt = new System.Windows.Forms.Button();
            this.update_bt = new System.Windows.Forms.Button();
            this.delete_bt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(393, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "이름 :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(390, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "학번 :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "반납일 : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "도서명 :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "도서번호 :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(379, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "대출일 : ";
            // 
            // booknum_txt
            // 
            this.booknum_txt.Location = new System.Drawing.Point(102, 22);
            this.booknum_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.booknum_txt.Name = "booknum_txt";
            this.booknum_txt.Size = new System.Drawing.Size(125, 25);
            this.booknum_txt.TabIndex = 9;
            // 
            // bookname_txt
            // 
            this.bookname_txt.Location = new System.Drawing.Point(102, 68);
            this.bookname_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bookname_txt.Name = "bookname_txt";
            this.bookname_txt.Size = new System.Drawing.Size(125, 25);
            this.bookname_txt.TabIndex = 10;
            // 
            // duedate_txt
            // 
            this.duedate_txt.Location = new System.Drawing.Point(102, 109);
            this.duedate_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.duedate_txt.Name = "duedate_txt";
            this.duedate_txt.Size = new System.Drawing.Size(125, 25);
            this.duedate_txt.TabIndex = 11;
            // 
            // userid_txt
            // 
            this.userid_txt.Location = new System.Drawing.Point(467, 22);
            this.userid_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userid_txt.Name = "userid_txt";
            this.userid_txt.Size = new System.Drawing.Size(125, 25);
            this.userid_txt.TabIndex = 12;
            // 
            // name_txt
            // 
            this.name_txt.Location = new System.Drawing.Point(467, 68);
            this.name_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(125, 25);
            this.name_txt.TabIndex = 13;
            // 
            // borrowdate_txt
            // 
            this.borrowdate_txt.Location = new System.Drawing.Point(467, 109);
            this.borrowdate_txt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.borrowdate_txt.Name = "borrowdate_txt";
            this.borrowdate_txt.Size = new System.Drawing.Size(125, 25);
            this.borrowdate_txt.TabIndex = 14;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 224);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(797, 428);
            this.dataGridView1.TabIndex = 16;
            // 
            // new_bt
            // 
            this.new_bt.Location = new System.Drawing.Point(472, 659);
            this.new_bt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.new_bt.Name = "new_bt";
            this.new_bt.Size = new System.Drawing.Size(80, 36);
            this.new_bt.TabIndex = 17;
            this.new_bt.Text = "등록";
            this.new_bt.UseVisualStyleBackColor = true;
            this.new_bt.Click += new System.EventHandler(this.new_bt_Click);
            // 
            // save_bt
            // 
            this.save_bt.Location = new System.Drawing.Point(733, 659);
            this.save_bt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.save_bt.Name = "save_bt";
            this.save_bt.Size = new System.Drawing.Size(80, 36);
            this.save_bt.TabIndex = 18;
            this.save_bt.Text = "저장";
            this.save_bt.UseVisualStyleBackColor = true;
            this.save_bt.Click += new System.EventHandler(this.save_bt_Click);
            // 
            // update_bt
            // 
            this.update_bt.Location = new System.Drawing.Point(646, 659);
            this.update_bt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.update_bt.Name = "update_bt";
            this.update_bt.Size = new System.Drawing.Size(80, 36);
            this.update_bt.TabIndex = 19;
            this.update_bt.Text = "수정";
            this.update_bt.UseVisualStyleBackColor = true;
            this.update_bt.Click += new System.EventHandler(this.update_bt_Click);
            // 
            // delete_bt
            // 
            this.delete_bt.DialogResult = System.Windows.Forms.DialogResult.No;
            this.delete_bt.Location = new System.Drawing.Point(559, 659);
            this.delete_bt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.delete_bt.Name = "delete_bt";
            this.delete_bt.Size = new System.Drawing.Size(80, 36);
            this.delete_bt.TabIndex = 20;
            this.delete_bt.Text = "삭제";
            this.delete_bt.UseVisualStyleBackColor = true;
            this.delete_bt.Click += new System.EventHandler(this.delete_bt_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.borrowdate_txt);
            this.panel1.Controls.Add(this.name_txt);
            this.panel1.Controls.Add(this.userid_txt);
            this.panel1.Controls.Add(this.duedate_txt);
            this.panel1.Controls.Add(this.bookname_txt);
            this.panel1.Controls.Add(this.booknum_txt);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(98, 36);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(643, 154);
            this.panel1.TabIndex = 21;
            // 
            // BorrowBookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 710);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.delete_bt);
            this.Controls.Add(this.update_bt);
            this.Controls.Add(this.save_bt);
            this.Controls.Add(this.new_bt);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "BorrowBookForm";
            this.Text = "BorrowBookForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox booknum_txt;
        private System.Windows.Forms.TextBox bookname_txt;
        private System.Windows.Forms.TextBox duedate_txt;
        private System.Windows.Forms.TextBox userid_txt;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox borrowdate_txt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button new_bt;
        private System.Windows.Forms.Button save_bt;
        private System.Windows.Forms.Button update_bt;
        private System.Windows.Forms.Button delete_bt;
        private System.Windows.Forms.Panel panel1;
    }
}